﻿using RimWorld.Planet;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;
using VFECore.Abilities;
using PsyMass;
using PsyMassMod;

namespace PsyMass
{
    public class ThingDef_CosmicBolt : ThingDef
    {
        public HediffDef HediffToAdd; // Not putting a default here.
        public float AddHediffChance = 0.5f;
    }

    public class Projectile_CosmicBolt : Bullet
    {
        #region Properties
        //
        public ThingDef_CosmicBolt Def
        {
            get
            {
                return this.def as ThingDef_CosmicBolt;
            }
        }
        #endregion Properties


        #region Overrides

        protected override void Impact(Thing hitThing, bool blockedByShield = false)
        {
            if (Def != null && hitThing != null && hitThing is Pawn hitPawn) //Fancy way to declare a variable inside an if statement. - Thanks Erdelf.
            {
                Pawn pawn = hitThing as Pawn;
                BodyPartRecord bodyPartRecord = hitPawn?.health.hediffSet.GetBrain();
                if (bodyPartRecord != null)
                {
                    int num = Rand.RangeInclusive(1, 5);
                    if (!pawn.Dead) { OffensivePowers.CA_AddPawnDamage(hitPawn, 1, 3); }
                    //GlobalTargetInfo globalTargetInfo = pawn;                    
                    //pawn.Map.weatherManager.eventHandler.AddEvent(new WeatherEvent_LightningStrike(pawn.Map, globalTargetInfo.Cell));
                    //hitPawn.TakeDamage(new DamageInfo(DamageDefOf.Flame, num, 0f, -1f, base.hitPawn, bodyPartRecord));
                }
            }
            base.Impact(hitThing);
        }
        #endregion Overrides
    }
}
