﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;

namespace PsyMassMod
{
    public class PawnFunctions
    {
        public static int Get_Psy_Level(Pawn pawn)
        {
            if (pawn != null && pawn.psychicEntropy != null)
            {                
                return pawn.GetPsylinkLevel();             
            }
            return 0;
            //Log.Message($"Caster's psy level is {psyLevel}");
        }

        public static bool HasMasochistTrait(Pawn pawn)
        {
            if (pawn == null || pawn.Dead || !pawn.RaceProps.Humanlike || !pawn.Spawned) { return false; }
            if (pawn?.story?.traits != null)
            {
                // Look for the Masochist trait using the trait defName
                Trait masochistTrait = pawn.story.traits.GetTrait(TraitDef.Named("Masochist"));
                return masochistTrait != null;
            }
            return false;
        }

        public static void SickStick_SetPawnMemory(Pawn TargetPawn, string strMemory = "AteWithoutTable")
        {
            if (TargetPawn == null || TargetPawn.Dead || !TargetPawn.RaceProps.Humanlike || !TargetPawn.Spawned) { return; }
            ThoughtDef PawnFeeling = ThoughtDef.Named(strMemory);
            Thought_Memory pawnMemory = (Thought_Memory)ThoughtMaker.MakeThought(PawnFeeling);
            TargetPawn.needs.mood.thoughts.memories.TryGainMemory(pawnMemory);
            return;
        }

        public static void SickStick_SetPawnSocialThought(Pawn TargetPawn, Pawn ParentPawn, string strThought = "WSSS_OTHER_FORCED_VOMIT")
        {
            if (TargetPawn == null || TargetPawn.Dead || !TargetPawn.RaceProps.Humanlike || !TargetPawn.Spawned) { return; }
            ThoughtDef thoughtDef = ThoughtDef.Named(strThought);
            Thought_MemorySocial thought = (Thought_MemorySocial)ThoughtMaker.MakeThought(thoughtDef);
            thought.otherPawn = ParentPawn;
            thought.moodPowerFactor = -1f;
            TargetPawn.needs.mood.thoughts.memories.TryGainMemory(thought);
            return;
        }
    }
}
