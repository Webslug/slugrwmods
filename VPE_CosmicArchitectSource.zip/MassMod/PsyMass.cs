﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PsyMass;
using Verse;
using UnityEngine;
using Verse.AI;
using VanillaPsycastsExpanded;
using VFECore.Abilities;
using RimWorld.Planet;
using System.Security.Cryptography;
using VFECore;
using System.Net;
using static PsyMass.PsyMassMod;
using System.Reflection;
using HarmonyLib;
using static UnityEngine.GraphicsBuffer;
using PsyMassMod;
using System.Collections;

namespace PsyMass
{

    using Verse;
    using RimWorld;


    public class AbilityExtension_DupePower : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            int PsyLevel = PawnFunctions.Get_Psy_Level(parentPawn); //Get the Psy level of the parent casting pawn
            float psySensitivity = parentPawn.GetStatValue(StatDefOf.PsychicSensitivity, true);
            if (targets.Length < 2) { Log.Warning("Dupe Power ability requires exactly two targets."); return; }

            // Get the thing to duplicate
            Thing thingToDuplicate = targets[0].Thing;
            IntVec3 targetLocation = targets[1].Cell;

            if (thingToDuplicate == null || !thingToDuplicate.Spawned) { return; }
            
            if (thingToDuplicate == null)
            {
                Log.Warning("No valid item to duplicate.");
                return;
            }

            // Calculate stack size to duplicate
            int stackCount = thingToDuplicate.stackCount;

            // Create a duplicate of the item with the same stack count
            Thing duplicate = ThingMaker.MakeThing(thingToDuplicate.def);
            duplicate.stackCount = stackCount;

            // Spawn the duplicate at the target location
            GenPlace.TryPlaceThing(duplicate, targetLocation, parentPawn.Map, ThingPlaceMode.Near);

            //Log.Message($"Duplicated {thingToDuplicate.def.label} with quantity {stackCount} at location {targetLocation}.");
        }
    }

    public class AbilityExtension_DenseBuilding : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            int PsyLevel = PawnFunctions.Get_Psy_Level(parentPawn); //Get the Psy level of the parent casting pawn
            float psySensitivity = parentPawn.GetStatValue(StatDefOf.PsychicSensitivity, true);
            int psyLevel = PawnFunctions.Get_Psy_Level(parentPawn);
            foreach (var target in targets)
            {
                if (target.Thing is Building building )
                {
                    int newMaxHitPoints = building.MaxHitPoints + (1000 * psyLevel);
                    typeof(ThingWithComps).GetField("maxHitPointsInt", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)?.SetValue(building, newMaxHitPoints);
                    building.HitPoints = newMaxHitPoints;
                    GenDraw.DrawFieldEdges(new List<IntVec3> { building.Position });
                }
            }
        }
    }


    public class AbilityExtentsion_LesserBurden : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            base.Cast(targets, ability);
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            int PsyLevel = PawnFunctions.Get_Psy_Level(parentPawn); //Get the Psy level of the parent casting pawn

            foreach (GlobalTargetInfo globalTargetInfo in targets)
            {
                if (globalTargetInfo.HasThing)
                {
                    Thing thing = globalTargetInfo.Thing;

                    // Reduce the mass of the thing by 50%
                    thing.def.statBases.Find(s => s.stat == StatDefOf.Mass).value *= 0.5f;

                    // Handle special cases for walls or other specific buildings if necessary
                    if (thing is Building)
                    {
                        Building building = thing as Building;
                        building.def.statBases.Find(s => s.stat == StatDefOf.Mass).value *= 0.5f;
                    }
                }
                else if (globalTargetInfo.Cell.IsValid && globalTargetInfo.Map != null)
                {
                    List<Thing> thingsInCell = globalTargetInfo.Cell.GetThingList(globalTargetInfo.Map);
                    foreach (Thing thing in thingsInCell)
                    {
                        // Reduce the mass of the thing by 50%
                        thing.def.statBases.Find(s => s.stat == StatDefOf.Mass).value *= 0.5f;

                        // Handle special cases for walls or other specific buildings if necessary
                        if (thing is Building)
                        {
                            Building building = thing as Building;
                            building.def.statBases.Find(s => s.stat == StatDefOf.Mass).value *= 0.5f;
                        }
                    }
                }
            }
        }
    }



}
