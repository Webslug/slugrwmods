﻿using PsyMassMod;
using RimWorld.Planet;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;
using VFECore.Abilities;

namespace PsyMass
{
    public class AbilityExtension_PullPower : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            if (targets.Length < 2) { Log.Warning("Pull Power ability requires exactly two targets."); return; }

            var TargetBattery = targets[0].Thing as Building;
            Pawn TargetPawn = targets[1].Thing as Pawn;
            int PsyLevel = PawnFunctions.Get_Psy_Level(parentPawn); //Get the Psy level of the parent casting pawn

            if (TargetBattery == null || !TargetBattery.Spawned) { return; }
            if (TargetPawn == null || TargetPawn.Dead || !TargetPawn.Spawned) { return; }
            if (TargetBattery is Building building)
            {
                //need to see if the building has CompProperties_Battery or storedEnergyMax?
                var batteryComp = TargetBattery.TryGetComp<CompPowerBattery>();

                if (batteryComp != null)
                {
                    //Log.Message("Battery object identified.");

                    // Define the percentage of max capacity to transfer, e.g., 0.6 for 60%
                    float transferPercentage = 0.2f;

                    // Get the maximum capacity of the battery
                    float maxCapacity = batteryComp.Props.storedEnergyMax;
                    float energyToTransfer = maxCapacity * transferPercentage;

                    // Deduct the energy from the battery, ensuring it does not draw more than available
                    batteryComp.DrawPower(Mathf.Min(energyToTransfer, batteryComp.StoredEnergy));

                    Need_Rest fNeed_Rest = TargetPawn.needs.TryGetNeed<Need_Rest>();
                    if (fNeed_Rest != null)
                    {
                        // Check the current rest level
                        float currentRestLevel = fNeed_Rest.CurLevel;

                        // Add 10% to the existing rest level, capped at 99%
                        fNeed_Rest.CurLevel = Mathf.Min(currentRestLevel + 0.1f, 0.99f);
                    }

                }
                else
                {
                    Log.Warning("Target building is not a battery or cannot store energy.");
                }
            }
        }
    }

    public class AbilityExtension_PushPower : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            if (targets.Length < 2) { Log.Warning("Push Power ability requires exactly two targets."); return; }

            var TargetPawn = targets[0];
            var TargetBattery = targets[1].Thing as Building;
            int PsyLevel = PawnFunctions.Get_Psy_Level(parentPawn); //Get the Psy level of the parent casting pawn

            if (TargetPawn.Thing is Pawn)
            {
                Pawn pawn = TargetPawn.Thing as Pawn;
                if (pawn != null && !pawn.Dead && pawn.Spawned)
                {
                    if (pawn.RaceProps.FleshType == FleshTypeDefOf.Mechanoid)
                    {
                        Need_MechEnergy fMechEnergy = pawn.needs.TryGetNeed<Need_MechEnergy>();
                        if (fMechEnergy != null && fMechEnergy.CurLevel >= 0.0f) { fMechEnergy.CurLevel = 0.01f; }
                    }
                    if (pawn.RaceProps.FleshType != FleshTypeDefOf.Mechanoid)
                    {
                        Need_Rest fNeed_Rest = pawn.needs.TryGetNeed<Need_Rest>();
                        if (fNeed_Rest != null && fNeed_Rest.CurLevel >= 0.10f)
                        {
                            fNeed_Rest.CurLevel = Mathf.Max(fNeed_Rest.CurLevel - 0.1f, 0.01f);
                        }
                    }
                }
            }
            if (TargetBattery is Building building)
            {
                var batteryComp = TargetBattery.TryGetComp<CompPowerBattery>();
                if (batteryComp != null)
                {
                    float transferPercentage = 0.1f;

                    // Get the maximum capacity of the battery
                    float maxCapacity = batteryComp.Props.storedEnergyMax;
                    float energyToTransfer = maxCapacity * transferPercentage;

                    // Add energy to the battery, ensuring it doesn't exceed max capacity
                    batteryComp.AddEnergy(Mathf.Min(energyToTransfer, maxCapacity - batteryComp.StoredEnergy));
                }
            }
            else { Log.Message("Building not identified."); }

            return;
        }
    }
}
