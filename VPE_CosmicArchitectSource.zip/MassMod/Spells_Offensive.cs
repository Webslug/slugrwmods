﻿using RimWorld;
using RimWorld.Planet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using VanillaPsycastsExpanded;
using Verse;
using VFECore.Abilities;
using PsyMass;
using PsyMassMod;

namespace PsyMass
{
    public class AbilityExtension_Fireballx : VFECore.Abilities.Ability
    {
        public override bool ValidateTarget(LocalTargetInfo target, bool showMessages = true)
        {
            if (!(target.Thing is Pawn thing) || thing.GetStatValue(StatDefOf.PsychicSensitivity) <= 0f)
            {
                return false;
            }

            return base.ValidateTarget(target, showMessages);
        }

        public override void Cast(params GlobalTargetInfo[] targets)
        {
            base.Cast(targets);
            for (int i = 0; i < targets.Length; i++)
            {
                GlobalTargetInfo globalTargetInfo = targets[i];
                if (Rand.Chance(0.3f))
                {
                    Pawn pawn = globalTargetInfo.Thing as Pawn;
                    globalTargetInfo.Thing.TryAttachFire(0.5f, base.Caster);
                    BodyPartRecord bodyPartRecord = pawn?.health.hediffSet.GetBrain();
                    if (bodyPartRecord != null)
                    {
                        int num = Rand.RangeInclusive(1, 5);
                        pawn.TakeDamage(new DamageInfo(DamageDefOf.Flame, num, 0f, -1f, base.pawn, bodyPartRecord));
                    }
                }
            }
        }
    }

    public class AbilityExtension_Testing : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            int PsyLevel = PawnFunctions.Get_Psy_Level(parentPawn); //Get the Psy level of the parent casting pawn
            float psySensitivity = parentPawn.GetStatValue(StatDefOf.PsychicSensitivity, true);
            //Log.Message("Triggered.");

            for (int i = 0; i < targets.Length; i++)
            {
                var TargetPawn = targets[i];
                if (TargetPawn is Pawn && !TargetPawn.Pawn.Dead)
                {
                    Log.Message("Pawn found...");
                    GlobalTargetInfo globalTargetInfo = targets[0];
                    //GenExplosion.DoExplosion(globalTargetInfo.Cell, globalTargetInfo.Map, GetRadiusForPawn(), DamageDefOf.EMP, TargetPawn);
                    TargetPawn.Map.weatherManager.eventHandler.AddEvent(new WeatherEvent_LightningStrike(TargetPawn.Map, globalTargetInfo.Cell));
                }
            }
        }
    }


    public static class OffensivePowers {
        public static void CA_AddPawnDamage(Pawn pawn, int bodymin = 1, int bodymax = 3)
        {
            int dmgRoll = 2; int numberOfBodyParts = 3;

            if (pawn != null && !pawn.Dead)
            {
                DamageDef DamageRef = DamageDefOf.Burn;
                numberOfBodyParts = Rand.RangeInclusive(bodymin, bodymax);
                if (bodymin < 1 || bodymin > 16) { bodymin = 3; }
                if (bodymax < 1 || bodymax > 32) { bodymax = 10; }
                for (int i = 0; i < numberOfBodyParts; i++)
                {
                    dmgRoll = 1;
                    dmgRoll = Rand.RangeInclusive(1, 5);
                    if (dmgRoll <= 1) { DamageRef = DamageDefOf.Burn; }
                    if (dmgRoll == 2) { DamageRef = DamageDefOf.Cut; }
                    if (dmgRoll == 3) { DamageRef = DamageDefOf.Blunt; }
                    if (dmgRoll == 4) { DamageRef = DamageDefOf.Stab; }
                    if (dmgRoll >= 5) { DamageRef = DamageDefOf.Crush; }

                    BodyPartRecord bodyPart = pawn.health.hediffSet.GetRandomNotMissingPart(DamageRef);

                    // Check if the body part is valid
                    if (bodyPart != null)
                    {
                        // Damage the body part with random severity
                        float frandomSeverity = Rand.Range(0.01f, 0.04f);
                        DamageInfo damageInfo = new DamageInfo(DamageRef, frandomSeverity);
                        pawn.TakeDamage(damageInfo);
                    }
                }
            }
            return;
        }
    }
    
}
