﻿using RimWorld.Planet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VanillaPsycastsExpanded;
using Verse;
using VFECore.Abilities;

namespace PsyMass
{

    public class CAAbility_Freeze : VFECore.Abilities.Ability
    {
        public override void Cast(params GlobalTargetInfo[] targets)
        {
            base.Cast(targets);
            Projectile projectile = GenSpawn.Spawn(def.GetModExtension<AbilityExtension_Projectile>().projectile, pawn.Position, pawn.Map) as Projectile;
            if (projectile is AbilityProjectile abilityProjectile)
            {
                abilityProjectile.ability = this;
            }

            projectile?.Launch(pawn, pawn.DrawPos, (LocalTargetInfo)targets[0], (LocalTargetInfo)targets[0], ProjectileHitFlags.IntendedTarget);
            pawn.stances.SetStance(new Stance_Stand(GetDurationForPawn(), (LocalTargetInfo)targets[0], verb));
        }

        public override void ApplyHediffs(params GlobalTargetInfo[] targetInfo)
        {
            ApplyHediff(pawn);
        }
    }
}
