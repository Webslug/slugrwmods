﻿using HarmonyLib;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;

namespace PsyMass
{
    public class PsyMassMod : Mod
    {
        public static HediffDef VPE_CosmicRay;
        public class PsyMass : GameComponent
        {
            public PsyMass(Game game) : base()
            {
                // Initialization logic, if needed
            }

            public override void FinalizeInit()
            {
                base.FinalizeInit();

                // Initialization logic here
            }
            public override void GameComponentTick()
            {
                base.GameComponentTick();
            }
        }

        public class ExampleSettings : ModSettings
        {
            /// <summary>
            /// The three settings our mod has.
            /// </summary>
            public bool TH_NegatesPSYRes = false;
            public bool TH_DebugMode = false;

            public override void ExposeData()
            {
                Scribe_Values.Look(ref TH_DebugMode, "TH_DebugMode");
                base.ExposeData();
            }
        }
        
        ExampleSettings settings;

        /// <param name="content"></param>
        public PsyMassMod(ModContentPack content) : base(content)
        {
            this.settings = GetSettings<ExampleSettings>();
        }

        /// <param name="inRect">A Unity Rect with the size of the settings window.</param>
        public override void DoSettingsWindowContents(Rect inRect)
        {
            Listing_Standard listingStandard = new Listing_Standard();

            listingStandard.End();
            base.DoSettingsWindowContents(inRect);
        }
        public class CompProperties_Health : CompProperties
        {
            public int maxHealth;

            public CompProperties_Health()
            {
                this.compClass = typeof(CompHealth);
            }
        }

        [HarmonyPatch(typeof(Building), "GetStatValue")]
        public class Patch_Building_GetStatValue
        {
            public static void Postfix(Building __instance, ref float __result, StatDef stat)
            {
                if (stat == StatDefOf.MaxHitPoints)
                {
                    __result *= 2; // Double the max hit points
                }
            }
        }

        public class CompHealth : ThingComp
        {
            private int health;

            public int Health
            {
                get { return health; }
                set { health = value; }
            }

            public void SetHealth(int newHealth)
            {
                health = newHealth;
            }
        }
        public override string SettingsCategory()
        {
            return "TH_PsyMass".Translate();
        }
    }
}
