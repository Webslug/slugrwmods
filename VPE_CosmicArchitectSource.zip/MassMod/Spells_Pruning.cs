﻿using PsyMassMod;
using RimWorld;
using RimWorld.Planet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VanillaFurnitureExpanded;
using Verse;
using VFECore.Abilities;

namespace PsyMass
{
    public class AbilityExtension_ClearEntities : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned || targets.Length == 0) { return; }
            float radius = 8f;
            var map = parentPawn.Map;

            foreach (var thing in map.listerThings.AllThings)
            {
                if (thing.Position.InHorDistOf(targets[0].Cell, radius) &&
                   ((thing is Pawn p && p.Dead) || thing.def.category == ThingCategory.Filth || thing.def.plant != null))
                {
                    thing.Destroy();
                }
            }
            /*
            foreach (IntVec3 cell in GenRadial.RadialCellsAround(targets[1].Cell, radius, true))
            {
                if (cell.InBounds(map))
                {
                    map.snowGrid.SetDepth(cell, 0f);
                }
            }*/
        }
    }

    //Need to evaluate if thingToUpgrade  is a piece of apparel, a weapon or an piece of furniture. If it is a pawn, wall or plant then return.
    //The Psy level of the caster as determined by PsyLevel should determine what the maximum level they can upgrade it too.
    //Evaluate if the object has a quality, poor, normal, good, excellent, legendary
    //If the object has a quality level upgrade it one tier accordingly, 
    //Level 3 = Normal, Level 4 = Excellent, Level 5 = Legendary 
    // Ensure that the target is valid
    public class AbilityExtension_UpgradeObject : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            int psyLevel = PawnFunctions.Get_Psy_Level(parentPawn);
            Thing thingToUpgrade = targets[0].Thing;
            //|| thingToUpgrade.def.IsBuildingArtificial

            if (thingToUpgrade == null || thingToUpgrade is Pawn || thingToUpgrade.def.plant != null || thingToUpgrade.def.IsCorpse) return;
            if (thingToUpgrade.def.IsMedicine || thingToUpgrade.def.IsMeat || thingToUpgrade.def.IsDrug || thingToUpgrade.def.IsDoor) return;

            QualityCategory currentQuality;
            if (thingToUpgrade.TryGetQuality(out currentQuality) && currentQuality < QualityCategory.Legendary)
            {
                QualityCategory newQuality = currentQuality + 1;
                if (psyLevel < 3 && newQuality > QualityCategory.Normal) newQuality = QualityCategory.Normal;
                else if (psyLevel < 4 && newQuality > QualityCategory.Excellent) newQuality = QualityCategory.Excellent;
                else if (psyLevel < 5 && newQuality > QualityCategory.Legendary) newQuality = QualityCategory.Legendary;

                thingToUpgrade.TryGetComp<CompQuality>()?.SetQuality(newQuality, ArtGenerationContext.Colony);
            }
        }
    }

    public class AbilityExtension_DestroyObject : AbilityExtension_AbilityMod
    {
        public override void Cast(GlobalTargetInfo[] targets, VFECore.Abilities.Ability ability)
        {
            Pawn parentPawn = ability.Caster as Pawn;
            if (parentPawn == null || parentPawn.Dead || !parentPawn.Spawned) { return; }
            int PsyLevel = PawnFunctions.Get_Psy_Level(parentPawn); // Get the Psy level of the parent casting pawn

            Thing thingToDelete = targets[0].Thing;

            // Ensure that the target is valid
            if (thingToDelete == null || thingToDelete is Pawn || thingToDelete.def.IsDoor)
            {
                return;
            }

            // Additional logging for confirmation
            //Log.Message($"Destroying {thingToDelete.Label} at {thingToDelete.Position}.");

            // Destroy the object
            thingToDelete.Destroy(DestroyMode.Vanish); // DestroyMode.Vanish will remove it without leaving a corpse or filth
        }
    }
}
